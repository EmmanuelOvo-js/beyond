<?php
include_once("db.php");
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sqlz = "INSERT INTO coder (Username)
VALUES ('ytt')";

if (mysqli_query($conn, $sqlz)) {
    $last_id = mysqli_insert_id($conn);
   
//    echo "New record created successfully. Last inserted ID is: " . $last_id;
} else {
   
}
?>

 <?php
include_once("db.php");

if(!empty($_FILES)){
$upload_dir = "uploads/";
$fileName = $_FILES['file']['name'];


 $newfilename = (rand(100000,1000000000)).$row_user['Username'];
  $ext = pathinfo($fileName, PATHINFO_EXTENSION);
  $dot = '.';

if(move_uploaded_file($_FILES['file']['tmp_name'],'uploads/'.$newfilename.$dot.$ext)){
  $er = $last_id - 1;
//insert file information into db table
$mysql_insert = "INSERT INTO uploads (`file`,adsid)VALUES('".'uploads/'.$newfilename.$dot.$ext."','".$er."')";
mysqli_query($conn, $mysql_insert) or die("database error:". mysqli_error($conn));
}
}

?><?php if ($row_user['entries'] != '0') {?>

<?php if (!isset($_POST['title'])){?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.5.1/dropzone.css">
        <!-- property area -->
        <div class="content-area submit-property" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">
                <div class="clearfix" > 
                    <div class="wizard-container"> 

                        <div class="wizard-card ct-wizard-orange" id="wizardProperty">
                            <form  name="wizard-card form" id="wizard-card form" method="post" action="createad.php" enctype='multipart/form-data'>                        
                                <div class="wizard-header">
                                    <h3>
                                        <b>Submit</b> YOUR BUSINESS ADVERT <br>
                                        <small></small>
                                    </h3>
                                </div>

                                <ul>
                                    <li><a href="#step1" data-toggle="tab">Step 1 </a></li>
                                    <li><a href="#step2" data-toggle="tab">Step 2 </a></li>
                                    <li><a href="#step3" data-toggle="tab">Step 3 </a></li>
                                    <li><a href="#step4" data-toggle="tab">Finished </a></li>
                                </ul>

                                <div class="tab-content">

                                    <div class="tab-pane" id="step1">
                                        <div class="row p-b-15  ">
                                            <h4 class="info-text"> Create Advert</h4>
                                            <input type="hidden" name="mine" value="<?php echo $last_id;?>"?>
                                               
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label>Title <small>(required)</small></label>
                                                    <input name="title" id="title"  type="text" class="form-control" placeholder="...">
                                                </div>

                                                <div class="form-group">
                                                    <label> price <small>(required)</small></label>
                                                    <input name="price" id="price"  type="number" class="form-control" placeholder="">
                                                </div> 
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <!--  End step 1 -->

                                    <div class="tab-pane" id="step2">
                                        <h4 class="info-text"> Tell Us About Your Business Advert </h4>
                                        <div class="row">
                                            <div class="col-sm-12"> 
                                                <div class="col-sm-12"> 
                                                    <div class="form-group">
                                                        <label>Business Description :</label>
                                                        <textarea  rows="14" cols="50" name="description" id="description" class="form-control" ></textarea>
                                                    </div> 
                                                </div> 
                                            </div>

                                        </div>
                                    </div>
                                    <!-- End step 2 -->

                                    <div class="tab-pane" id="step3">                                        
                                        <h4 class="info-text">Give us some images ? </h4>
                                        <div class="row">  
                                            <div class="col-sm-10">
                                                <div class="form-group">
                                                    <label for="property-images">Chose Images :</label>
                                                  
                                                  <link rel="stylesheet" href="drop.css">
 

  
      <div id="dropzone" class="dropzone"></div>

                                                </div>
                                            </div>
                                           
                                        </div>
                                    </div>
                                    <!--  End step 3 -->


                                    <div class="tab-pane" id="step4">                                        
                                        <h4 class="info-text"> Finished and submit </h4>
                                        <div class="row">  
                                            <div class="col-sm-12">
                                                <div class="">
                                                   
                                                    

                                                    <div class="checkbox">
                                                        <label>
                                                           <?php if ($row_user['featured'] != '0') {?> <input type="checkbox" name="feat" value='yes' /> <strong>Apply for featured preferencing?.</strong><?php }?>
                                                           <?php if ($row_user['featured'] == '0') {?>  <span style="color : red;font-weight : bold;font-size : 18px">Featured preferencing Unavailable</span><?php }?>
                                                        </label>
                                                    </div> 

                                                </div> 
                                            </div>
                                        </div>
                                    </div>
                                    <!--  End step 4 -->

                                </div>

                                <div class="wizard-footer">
                                    <div class="pull-right">
                                        <input type='button' class='btn btn-next btn-primary' name='next' value='Next' />
                                        
                                        
                                        
                                        <button class='btn btn-finish btn-primary '  type="submit" id="startUpload">Finish</button>
                                        
                                    </div>

                                    <div class="pull-left">
                                        <input type='button' class='btn btn-previous btn-default' name='previous' value='Previous' />
                                    </div>
                                    <div class="clearfix"></div>                                            
                                </div>	
                            </form>
                        </div>
                        <!-- End submit form -->
                    </div> 
                </div>
            </div>
        </div>
        <?php }?><?php }?>
        
        <?php if ($row_user['entries'] == '0') {?>
        <br /> <br /> <br /> <br />
        
        <div align="center"><h2><?php if (!empty($row_user['package'])) {?>Your access under your present package has been exausted please upgrade or renew package</h2><?php }?><?php if (empty($row_user['package'])) {?>You Have no Active Package</h2><?php }?>
         <br /><a class="btn btn-previous btn-default" href="package.php">Subscribe Now</a> <br /> <br /> <br /> <br /></div>
        
        <?php }?>
        
        <?php if (isset($_POST['title'])){?>
     
<?php

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$title = $_POST['title'];
$price = $_POST['price'];
$description = $_POST['description'];
$usern = $row_user['Username'];

$sqld = "INSERT INTO advert (title,price,description,adsid,Username)
VALUES ('$title','$price','$description','$last_id','$usern')";

if (mysqli_query($conn, $sqld)) {
   // $last_id = mysqli_insert_id($conn);
//    echo "New record created successfully. Last inserted ID is: " . $last_id;
$servername = "localhost";
$username = $username_emirate;
$password = $password_emirate;
$dbname = $database_emirate;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


error_reporting(1);

$usern = $row_user['Username'];
$feat = $_POST['feat'];

if ($feat == 'yes')
{
  $sql = "UPDATE users
           SET entries = entries - 1, featured = featured - 1
         WHERE  Username = '$usern'";
}
else {
     $sql = "UPDATE users
           SET entries = entries - 1
         WHERE  Username = '$usern'";
    
}
         
         
         

if ($conn->query($sql) === TRUE) {
    //echo '<strong>Please </strong>wait while you are redirected
   // <br />';
    
        echo'<meta http-equiv="refresh" content="2; url=createad.php" />';

} else {
    echo "Error updating record: " . $conn->error;
}
    


} else {
   
}




?>

<?php }?>
      <?php if (isset($_POST['title'])){?>
<?php
echo '<br /><br /><br /><div align="center"><h2>Business Advert Created</h2></div><br /><br /><br /><br /><br /><br />';

?>

<?php }?>
