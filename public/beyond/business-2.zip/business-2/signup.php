<?php $pagetype = 'signup'; ?>
<?php include('indexheader.php');?>
<?php include('nav.php');?>
<?php include('regbody.php');?>
<?php include('indexfooter.php');?>