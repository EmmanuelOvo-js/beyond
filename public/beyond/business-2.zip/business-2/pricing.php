<?php $pagetype = 'package'; ?>
<?php include('indexheader.php');?>
<?php include('nav.php');?>
<?php include('pricingbody.php');?>
<?php include('indexfooter.php');?>