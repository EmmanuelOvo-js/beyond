<?php $pagetype = 'moreinfo'; ?>
<?php include('indexheader.php');?>
<?php include('nav.php');?>
<?php include('moreinfobody.php');?>
<?php include('indexfooter.php');?>