<?php require_once('Connections/emirate.php'); ?>

<?php
$servername = "localhost";
$username = $username_emirate;
$password = $password_emirate;
$dbname = $database_emirate;;
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>