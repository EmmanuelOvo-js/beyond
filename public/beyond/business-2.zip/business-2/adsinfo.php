<?php $pagetype = 'adsinfo'; ?>
<?php include('indexheader.php');?>
<?php include('nav.php');?>
<?php include('adsinfobody.php');?>
<?php include('indexfooter.php');?>