<?php require_once('Connections/emirate.php'); ?>
<?php

//If the HTTPS is not found to be "on"
if(!isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on")
{
    //Tell the browser to redirect to the HTTPS URL.
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"], true, 301);
    //Prevent the rest of the script from executing.
    exit;
}

if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_emirate, $emirate);
$query_site = "SELECT * FROM site";
$site = mysql_query($query_site, $emirate) or die(mysql_error());
$row_site = mysql_fetch_assoc($site);
$totalRows_site = mysql_num_rows($site);


?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php
        if ($pagetype == 'dashboard'){?>
        
        Dashboard
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'users'){?>
        
        All Users
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'referrals'){?>
        
        All Users With Most Referrals
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'payouts'){?>
        
        All Payouts
        
         
         <?php } ?>
         <?php
    if ($pagetype == 'transaction'){?>
    
    All Transactions
        
         
         <?php } ?>
        
         <?php
        if ($pagetype == 'verify'){?>
        
        Transaction Verification
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'profile'){?>
        
        Update Profile
        
         
         <?php } ?>
         <?php
    if ($pagetype == 'proposal'){?>
    
    View proposal
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'password'){?>
        
        Update Password
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'bank'){?>
        
        Update Bank Details
        
         
         <?php } ?>
         
         <?php
        if ($pagetype == 'picture'){?>
        
        Update Picture
        
         
         <?php } ?>
         <?php
        if ($pagetype == 'package'){?>
        
        Choose Package
        
         
         <?php } ?>
           <?php
        if ($pagetype == 'myjobs'){?>
        
        My Jobs
        
         
         <?php } ?>
         <?php
    if ($pagetype == 'apply'){?>
    
    Apply Now
        
         
         <?php } ?>
         
           <?php
    if ($pagetype == 'alljobs'){?>
    
    All Jobs
        
         
         <?php } ?>
         <?php
    if ($pagetype == 'findjobs'){?>
    
    Find Jobs
        
         
         <?php } ?>
        
<?php
    if ($pagetype == 'updatejob'){?>Update Job
        
         
         <?php } ?>

           <?php
    if ($pagetype == 'clientjobs'){?>
    
    My Created Jobs
        
         
         <?php } ?>
         <?php
    if ($pagetype == 'viewmore'){?>
    
    View More
        
         
         <?php } ?>
           <?php
    if ($pagetype == 'addjob'){?>
    
    Add Job
        
         
         <?php } ?>
          
         
         
         / <?php echo $row_site['name']; ?></title>
        <meta name="description" content="<?php echo $row_site['name']; ?>">
        <meta name="author" content="<?php echo $row_site['name']; ?>">
        <meta name="keyword" content="<?php echo $row_site['name']; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">

       

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
        <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
        <link rel="icon" href="favicon.ico" type="image/x-icon">

        <link rel="stylesheet" href="assets/css/normalize.css">
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
        <link rel="stylesheet" href="assets/css/fontello.css">
        <link href="assets/fonts/icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet">
        <link href="assets/fonts/icon-7-stroke/css/helper.css" rel="stylesheet">
        <link href="assets/css/animate.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" href="assets/css/bootstrap-select.min.css"> 
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/wizard.css">
        <link rel="stylesheet" href="assets/css/icheck.min_all.css">
        <link rel="stylesheet" href="assets/css/price-range.css">
        <link rel="stylesheet" href="assets/css/owl.carousel.css">  
        <link rel="stylesheet" href="assets/css/owl.theme.css">
        <link rel="stylesheet" href="assets/css/owl.transitions.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="stylesheet" href="assets/css/responsive.css">
    </head>