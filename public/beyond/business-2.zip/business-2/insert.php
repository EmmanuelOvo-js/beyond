<?php require_once('Connections/emirate.php'); ?>
Message Sent
<?php
 
 $reply = $_POST['email'];



    $replysubject = "New Business Request | Freelancer Africa";
    $replyfrom = "From: info@freelancer.africa\r\n";
     $replymessagess .= "You have just received a contact message, the  details are below.\r\n\r\n";
   
  
   $replymessagess .= "\r\n";
   
   $replymessagess .= "Fullname : ";
   
   
   $replymessagess .= $_POST['name'];
    
      $replymessagess .= "\r\n";
      
      $replymessagess .= "Email : ";
   
   
   $replymessagess .= $_POST['p-email'];
   $replymessagess .= "\r\n";$replymessagess .= "\r\n";
      
      $replymessagess .= "message : ";
   
   
   $replymessagess .= $_POST['message'];
    
      $replymessagess .= "\r\n";
      $replymessagess .= "\r\n";
  
     //$replymessagess .= "Please login to continue.\r\n\r\n";
    $replymessagess .= "http://business.freelancer.africa\r\n\r\n";
    $replymessagess .= "This e-mail is automated, so please do not reply.\r\n";
     $replymessagess .= "Regards.\r\n";
  mail($reply,$replysubject, $replymessagess, $replyfrom);  
 
 
    //Connection to MySQL
    $con = mysqli_connect('localhost', $username_emirate, $password_emirate);
 
    if(!$con) {
        die('Not Connected To Server');
    }
 
    //Connection to database
    if(!mysqli_select_db($con, $database_emirate)) {
        echo 'Database Not Selected';
    }
 
    //Create variables
    $name = $_POST['name'];
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];
    $message = mysqli_real_escape_string($con, $_POST['message']);
    $msgid = $_POST['msgid'];
    $Access = $_POST['Access'];
    $jobe = $_POST['jobe'];
   // $query = mysqli_query($con,"SELECT * FROM user WHERE Username='cggc' OR Password='ghvhg'");
   // $sql = "INSERT INTO conversation (jobid,notify,type,status,sender,receiver,name, message,proposalid) VALUES ('$jobe','no','$Access','new','$sender','$receiver','$name', '$message', '$msgid')";
 
    // echo '<h2 style="color : green">Message Sent</h2>';
  
    
   // if(!mysqli_query($con, $sql)) {
        //echo 'Could not insert';
   // }
   // else {
        
        
        
   // }
 
    //Close connection
    mysqli_close($con);
 
?>