<?php $pagetype = 'index'; ?>
<?php include('indexheader.php');?>
<?php include('nav.php');?>
<?php include('indexbody.php');?>
<?php include('indexfooter.php');?>