

        <!-- property area -->
        <div class="content-area user-profiel" style="background-color: #FCFCFC;">&nbsp;
            <div class="container">   
                <div class="row">
                    <div class="col-sm-10 col-sm-offset-1 profiel-container">

                   
                            <div class="profiel-header">
                                <h3>
                                    <b>More</b> About business Profile <br>
                                    <small></small>
                                </h3>
                                <hr>
                            </div>

                            <div class="clear">
                                <div class="col-sm-3 col-sm-offset-1">
                                    <div class="picture-container">
                                        <div class="picture">
                                            <?php

if (empty($row_use['picture'])){?>
                                        <img src="noimage.jpg">
<?php }?>
<?php

if (!empty($row_use['picture'])){?>
                                        <img src="<?php echo $row_use['picture']; ?>">
<?php }?>
                                        </div>
                                        
                                    </div>
                                </div>

                                <div class="col-sm-3 padding-top-25">

                                    <div class="form-group">
                                        <label>Business Name : <small></small></label><br />
                                          <?php

if (empty($row_use['bname'])){?>
<?php echo $row_use['fname']; ?> <?php echo $row_use['lname']; ?>

    <?php }?>
    <?php

if (!empty($row_use['bname'])){?>
<?php echo $row_use['bname']; ?> 

    <?php }?>
                                    </div>
                                    <div class="form-group">
                                        <label>Phone Number : <small></small></label><br />
                                        
<?php echo $row_use['number']; ?> 
                                    </div> 
                                   
                                </div>
                                <div class="col-sm-3 padding-top-25">
                                    <div class="form-group">
                                        <label>Email : <small></small></label>
                                       <br /> <?php echo $row_use['Email']; ?> 
                                    </div>
                                    
                                </div>  

                            </div>

                           <div class="profiel-header">
                               <h3>
                                    <b>Contact</b> <?php

if (empty($row_use['bname'])){?>
<?php echo $row_use['fname']; ?> <?php echo $row_use['lname']; ?>

    <?php }?>
    <?php

if (!empty($row_use['bname'])){?>
<?php echo $row_use['bname']; ?> 

    <?php }?> <br>
                                    <small></small>
                                </h3></div>
                                <hr>
                                <div align="center"><span align="center" style="color : green;font-size :18px;font-weight :bold;text-align : center" id="message"></span></div>
                                <br>
                                <form id="my-form" action="" method="post">
                                <div class="col-sm-5 col-sm-offset-1">
                                    <div class="form-group">
                                        <label>Fullname :</label>
                                        <input required name="name" type="text" class="form-control" placeholder="Fullname">
                                        <input type="hidden" name="email" value="<?php echo $row_use['Email']; ?>" />
                                    </div>
                                    
                                </div>  

                                <div class="col-sm-5">
                                    <div class="form-group">
                                        <label>Email :</label>
                                        <input required name="p-email" type="email" class="form-control" placeholder="p-email@rmail.com">
                                    </div>
                              
 
                            </div>
                    <div class="col-sm-10 col-sm-offset-1">
                        <textarea name="message" class="form-control"  rows="10" cols="50" required>

</textarea>
                        </div>
                            <div class="col-sm-5 col-sm-offset-1">
                                <br>
                                <input id="mySubmit"  type="submit"  class='btn btn-finish btn-primary' name='finish' value='Send Message' />
                            </div>
                            <br>
                    </form>

                </div>
            </div><!-- end row -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <!--AJAX-->
        <script>
        
            $(document).ready(function() {
                <!--#my-form grabs the form id-->
                $("#my-form").submit(function(e) {
                    e.preventDefault();
                    $.ajax( {
                        <!--insert.php calls the PHP file-->
                        url: "insert.php",
                        method: "post",
                        data: $("form").serialize(),
                        dataType: "text",
                        success: function(strMessage) {
                            $("#message").text(strMessage);
                            $("#my-form")[0].reset();
                        }
                    });
                });
            });
        </script>
        
        </div>
    </div>


  