<?php $pagetype = 'signin'; ?>
<?php include('indexheader.php');?>
<?php include('nav.php');?>
<?php include('signinbody.php');?>
<?php include('indexfooter.php');?>