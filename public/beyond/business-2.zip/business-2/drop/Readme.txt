Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: yogesh@makitweb.com, makitweb@gmail.com
Tutorial Link: https://makitweb.com/upload-file-using-dropzone-js-php/

