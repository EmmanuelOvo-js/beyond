<?php
             

if (isset($_POST['email']))
{
    $servername = "localhost";
$username = $username_emirate;
$password = $password_emirate;
$dbname = $database_emirate;
// Create connection


$conn = mysqli_connect($servername, $username, $password, $dbname);
$query = mysqli_query($conn, "SELECT * FROM users WHERE Email='$_POST[email]'");
//$querys = mysqli_query($conn, "SELECT * FROM users WHERE number='$_POST[phone]'");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

 if (mysqli_num_rows($query) > 0){
     echo ' Email Address Has Been Used!! 
           Please wait while you are been redirected!!';
    echo '<META HTTP-EQUIV="Refresh" Content="2; URL=index.php">';
}

else
{


//Checkconnection
if(mysqli_connect_errno())
{
echo"FailedtoconnecttoMySQL:".mysqli_connect_error();
}


$pass = md5($_POST['password']);

$sql="INSERT INTO users(entries,featured,amount,ratings,refid,reffered,Date,Access,Username,Email,Password,fname,lname,number)VALUES('0','0','0','0','$_POST[refid]','$_POST[reffered]','$_POST[dates]','member','$_POST[email]','$_POST[email]','$pass','$_POST[fname]','$_POST[lname]','$_POST[phone]')";




if (mysqli_query($conn, $sql)) {
    //echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}



$sql1="INSERT INTO verification(checkdate,Username,code)VALUES('$_POST[dates]','$_POST[email]','$_POST[code]')";




if (mysqli_query($conn, $sql1)) {
    //echo "New record created successfully";
} else {
    echo " " . $sql1 . "<br>" . mysqli_error($conn);
}




// handling notifications
// handling notifications
$whitelist = array(
    '127.0.0.1',
    '::1'
);

if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
 // echo 'loclahost';
    // not valid


   

}

echo '<br /><br />
<div align="center"><strong>Successfully Created Account,please wait while you are redirected!! </strong> Do not refresh the page</div>';
echo '<META HTTP-EQUIV="Refresh" Content="2; URL=index.php">';


mysqli_close($conn);
}
}
?>
     <?php
    
$servername = "localhost";
$username = $username_emirate;
$password = $password_emirate;
$dbname = $database_emirate;


// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$ourname = 'nullx';

//$ournames = $row_users['status'];
        //if ($ournames == 'unused')
    //{
    //$last_id = $row_users['id'];
    //}
//else{

$sqlz = "INSERT INTO coder (Username)
VALUES ('$ourname')";

if (mysqli_query($conn, $sqlz)) {
    $last_id = mysqli_insert_id($conn);
//    echo "New record created successfully. Last inserted ID is: " . $last_id;
} else {
   
}
?>

 
    
    
    <script language='javascript' type='text/javascript'>
    function check(input) {
        if (input.value != document.getElementById('password').value) {
            input.setCustomValidity('Password Must be Matching.');
        } else {
            // input is valid -- reset the error message
            input.setCustomValidity('');
        }
    }
</script>
  

      
        
  
 

        <!-- register-area -->
        <div class="register-area" style="background-color: rgb(249, 249, 249);">
            <div class="container">

                <div class="col-md-12">
                    <div class="box-for overflow">
                        <div class="col-md-12 col-xs-12 register-blocks">
                           
                           <?php

if (!isset($_POST['email'])){?> <h2>New account : </h2> 
                            
                            <form class="formcontainer" method="post" action="signup.php" name="signup" id="signup">
                                <input type="hidden" name="refid" value="<?php
$i = $last_id;
printf("%05d",$i);
?>"  />
<input type="hidden" name="code" value="<?php
$i = $last_id;
printf("%05d",$i);
?><?php
echo(rand(1000000,100000000));
?>"  />
<input type="hidden" value="<?php
 echo $row_ref['Username'];
 
 
  ?>" name="reffered" />
  <input type="hidden" value="<?php
//date_default_timezone_set("Africa/Lagos");
echo  date("Y-m-d");
?>" name="dates" />
                                <div class="form-group">
                                    <label for="name">First Name</label>
                                    
                                    <input required="required" type="text" class="form-control" id="p-signup-first-name" name="fname" placeholder="First Name">
                                </div>
                                <div class="form-group">
                                    <label for="name">Last Name</label>
                                    
                                    <input required="required" type="text" class="form-control" id="p-signup-last-name" name="lname" placeholder="Last Name">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input required="required" type="email" class="form-control" name="email" placeholder="Email Address">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input required=""  type="password" class="form-control" id="password" name="password"  placeholder="Password">
                                </div>
                                <div class="form-group">
                                    <label for="password">Confirm Password</label>
                                    <input required=""  type="password" class="form-control" id="confirm_password" name="passwordss" oninput="check(this)" placeholder="Confirm Password">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-default">Register</button>
                                </div>
                            </form>
                            <?php }?>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    
                </div>

            </div>
        </div>      

        
       