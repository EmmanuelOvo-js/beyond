<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_emirate = "localhost";
$database_emirate = "afreelan_business";
$username_emirate = "afreelan_busines";
$password_emirate = "famakin1-";
$emirate = mysql_pconnect($hostname_emirate, $username_emirate, $password_emirate) or trigger_error(mysql_error(),E_USER_ERROR); 
?>