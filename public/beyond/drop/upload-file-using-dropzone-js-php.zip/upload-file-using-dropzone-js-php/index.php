<!doctype html>
<html>
    <head>
        <link href="style.css" rel="stylesheet" type="text/css">
        <link href="dropzone.css" rel="stylesheet" type="text/css">
        <script src="dropzone.js" type="text/javascript"></script>
    </head>
    <body >
        <div class="container" >
            <div class='content'>
            <form action="upload.php" class="dropzone" id="dropzonewidget">
                
            </form>  
            </div> 
        </div>
    </body>
</html>